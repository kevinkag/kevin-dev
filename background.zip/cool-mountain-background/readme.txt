This template / effect / code has been created by Igor Milenkovic.
You can customize and check it out on its original site on the following link:
https://codepen.io/imilenig/pen/JxejbQ

Thank you